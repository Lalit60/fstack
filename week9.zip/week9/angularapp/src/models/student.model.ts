export interface Student {
  id?: any;
  name: string;
  department: string;
  phonenumber: string;
}
